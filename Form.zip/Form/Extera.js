//'<h1>Edit user detail</h1><form action="/Detail" method="POST"><button type="edit" value="edit">edit</button></form>')
        //<h1>The USER ID:</h1>'+req.body.username+
     //   '<h2>The USER Name:</h2>'+req.body.Email+
     //   '<h3>The USER EMAIL:</h3>'+req.body.Password+
      //  '<h4>The USER PASSWORD:</h4>'+user.Password+
      /*  '<h5>The USER CONFORMPASSWORD:</h5>'+user.confirmedPassword+*///'<form action="/Detail" method="POST"><button type="edit" value="edit">edit</button></form>' +d)


 //   app.post('/Detail',function(req,res){
   //      res.redirect('/')
   // })
//     fs.var data = JSON.stringify(userDetails);
//     fs.writeFile('userdetail.json', data , (err) => {
//         if(err) throw err;
//         console.log('Data send to the file');

//         res.send(JSON.stringify(userDetails));
//         console.log(userDetails.length);
//     });readFile('userdetail.json', function(err, data) {
//             res.writeHead(200, {'Content-Type': 'application/json'});
//             res.write(data);
//             res.end();
//           });
// });