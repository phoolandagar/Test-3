const express=require('express');
const router=express.Router();

router.post('/edit',(req,res)=>{
    res.render('route');
    
    const user = {
        Username:req.body.Username,
        Password:req.body.Password,
    }
    fs.readFile("pack.json",'utf8',function(err,data){
        var d = JSON.parse(data);
        var u = d.find((el)=>{
                return el.user ==user
        })
       res.send(u);
    })
    })          


module.exports=router;