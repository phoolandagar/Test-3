const express=require('express');
const jwt=require("jsonwebtoken");

const router=express.Router();
router.get('/api',(req,res)=>{
 res.json({
      message:"Welocme to the Api"
 });
});
router.post('/api/posts',verifyToken,(req,res)=>{
    jwt.verify(token,'secretKey',(err,authData)=> {
        if(err){
            res.sendStatus(403);
        }
        else{
             res.json({
      message:"IT IS CREATED.. .",
      authData
  });
}
    });
})
router.post('/api/login',(req,res)=>{
    const user={
       
     Username:"Neetu",
     Fathername:"Deshraj",
     Mobile:456666477,
    }
    jwt.sign({user:user},'secretKey',(err,token)=>{       
res.json({
    token:token
})
            
    })

})
//FORMAT OF TOKEN
//Autherization:Bearer <access_token>

function verifyToken(req,res,next){
       
const bearerHeader=req.headers['authorization'];
 
if(typeof bearerHeader !== 'undefined'){
     const bearer = bearerHeader.split(' ');
     const bearerToken=bearer[1];
     token=bearerToken;
     next();
}  else  { 
         res.sendStatus(403);
     }
    
    }

app.listen(8000,()=>{
console.log("server started on port 8000");

})

